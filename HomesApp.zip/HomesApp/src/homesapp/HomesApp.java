/*
 * Jake Horner and Ken Dolan
 * 5/10/2018
 * HomesApp.java
 */
package homesapp;

/**
 *
 * @author x16312261
 */
public class HomesApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        HomesGUI myGUI = new HomesGUI();
        myGUI.setVisible(true);
    }
    
}
